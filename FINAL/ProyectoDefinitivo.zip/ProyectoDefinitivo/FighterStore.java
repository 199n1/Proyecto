/**
 * Tienda tipo Fighter: solo entrega dinero si el robot tiene más tenges que ella.
 * La lógica de comparación se debe manejar desde SilkRoad.
 * 
 * @author Maria
 * @version 1.0
 */
public class FighterStore extends Store {

    /**
     * Crea una tienda tipo Fighter en una ubicación lógica específica.
     * 
     * @param location ubicación lógica dentro del camino
     * @param generator generador de colores para asignar color único
     * @param x coordenada horizontal para la visualización
     * @param y coordenada vertical para la visualización
     * @param tenges cantidad inicial de tenges
     */
    public FighterStore(int location, ColorGenerator generator, int x, int y, int tenges) {
        super(location, generator, x, y, tenges);
    }

    /**
     * Esta tienda no puede decidir si el robot puede usarla sin saber sus tenges.
     * Se asume que SilkRoad controla esa lógica.
     */
    @Override
    public boolean canBeUsedBy(Robot robot) {
        return true; // SilkRoad debe filtrar según tenges del robot
    }

    /**
     * Calcula la ganancia como en una tienda normal.
     * SilkRoad debe asegurarse de que el robot tenga más tenges antes de llamar.
     */
    @Override
    public int giveMoneyTo(Robot robot) {
        int gain = getTenges() - Math.abs(getLocation() - robot.getLocation());
        return Math.max(0, gain);
    }

    /**
     * Letra que identifica el tipo de tienda.
     */
    @Override
    public String getTypeLetter() {
        return "F";
    }
}