public class NormalStore extends Store {

    public NormalStore(int location, ColorGenerator generator, int x, int y, int tenges) {
        super(location, generator, x, y, tenges);
    }

    @Override
    public boolean canBeUsedBy(Robot robot) {
        return true;
    }

    @Override
    public int giveMoneyTo(Robot robot) {
        return getTenges();
    }

    @Override
    public String getTypeLetter() {
        return "N";
    }
}