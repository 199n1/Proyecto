public class EchoRobot extends Robot {

    private int lastMove = 0;

    public EchoRobot(int location, int maxLength, ColorGenerator generator, int x, int y) {
        super(location, maxLength, generator, x, y);
    }

    @Override
    public boolean canMove(int meters) {
        return true;
    }

    @Override
    public int adjustProfit(int rawProfit) {
        return rawProfit;
    }

    @Override
    public void rememberMove(int meters) {
        lastMove = meters;
    }

    @Override
    public int repeatMove() {
        return lastMove;
    }
}