public class NormalRobot extends Robot {

    public NormalRobot(int location, int maxLength, ColorGenerator generator, int x, int y) {
        super(location, maxLength, generator, x, y);
    }

    @Override
    public boolean canMove(int meters) {
        return true;
    }

    @Override
    public int adjustProfit(int rawProfit) {
        return rawProfit;
    }

    @Override
    public void rememberMove(int meters) {
        // no hace nada
    }

    @Override
    public int repeatMove() {
        return 0;
    }
}