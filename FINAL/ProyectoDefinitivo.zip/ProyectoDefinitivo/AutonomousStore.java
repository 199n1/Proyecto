public class AutonomousStore extends Store {
    public AutonomousStore(int location, ColorGenerator generator, int x, int y, int tenges) {
        super(location, generator, x, y, tenges);
    }

    @Override
    public boolean canBeUsedBy(Robot robot) {
        return getTenges() > 0;
    }

    @Override
    public int giveMoneyTo(Robot robot) {
        int gain = getTenges() - Math.abs(getLocation() - robot.getLocation());
        return Math.max(0, gain);
    }

    @Override
    public String getTypeLetter() {
        return "A";
    }
}