public class NeverbackRobot extends Robot {

    public NeverbackRobot(int location, int maxLength, ColorGenerator generator, int x, int y) {
        super(location, maxLength, generator, x, y);
    }

    @Override
    public boolean canMove(int meters) {
        return meters >= 0;
    }

    @Override
    public int adjustProfit(int rawProfit) {
        return rawProfit;
    }

    @Override
    public void rememberMove(int meters) {
        // no hace nada
    }

    @Override
    public int repeatMove() {
        return 0;
    }
}