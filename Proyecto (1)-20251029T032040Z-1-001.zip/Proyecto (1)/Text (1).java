 /**
 * Representa un texto visual en pantalla.
 * Se puede mover, cambiar de color, tamaño y visibilidad.
 */
public class Text {

    private String text;
    private String color;
    private int size;
    private int xPosition;
    private int yPosition;
    private boolean isVisible;

    public Text() {
        this.text = "";
        this.color = "black";
        this.size = 14;
        this.xPosition = 0;
        this.yPosition = 0;
        this.isVisible = false;
    }

    public void setText(String newText) {
        this.text = newText;
        update();
    }

    public void changeColor(String newColor) {
        this.color = newColor;
        update();
    }

    public void changeSize(int newSize) {
        this.size = newSize;
        update();
    }

    public void moveHorizontal(int distance) {
        xPosition += distance;
        update();
    }

    public void moveVertical(int distance) {
        yPosition += distance;
        update();
    }

    public void makeVisible() {
        isVisible = true;
        update();
    }

    public void makeInvisible() {
        isVisible = false;
        update();
    }

    public int getX() {
        return xPosition;
    }

    public int getY() {
        return yPosition;
    }

    private void update() {
        // Aquí iría la lógica para redibujar el texto en pantalla.
        // En tu simulador, probablemente ya hay una clase que lo maneja.
    }
}
