package logic;

/**
 * Modalidades del juego.
 */
public enum Modalidad {
    PLAYER,
    PVSP,
    PVSM,
    MVSM
}