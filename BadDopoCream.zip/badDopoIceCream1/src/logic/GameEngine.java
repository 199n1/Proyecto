package logic;

import domain.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Motor principal del juego: maneja tiempo, niveles, modalidades y perfiles de máquina.
 */
public class GameEngine implements Serializable {
    private static final long serialVersionUID = 1L;

    // Configuración y estado
    private Nivel nivelActual;
    private int numeroNivel;
    private int puntajeTotal;
    private int vidasRestantes;
    private boolean pausado;
    private boolean juegoTerminado;
    private boolean nivelCompletado;

    // Modalidades y perfiles IA
    private String modalidad;
    private PerfilMaquina perfilIA1;
    private PerfilMaquina perfilIA2;

    // Helados (jugadores o máquinas)
    private Helado helado;
    private Helado helado2;
    
    // Color del helado
    private String colorHelado;

    // Temporizador
    private ManejadorTiempo temporizador;

    // Configuración elegida por el usuario por nivel
    private List<TipoObstaculoMapa> obstaculosPorNivel;
    private List<TipoFruta[]> frutasPorNivel;
    private List<TipoEnemigo> enemigoPorNivel;

    /**
     * Constructor para modalidades simples (Player, PvsP, PvsM, MvsM)
     */
    public GameEngine(String modalidad, String colorHelado) throws GameException {
        this.modalidad = modalidad;
        this.colorHelado = colorHelado;
        this.puntajeTotal = 0;
        this.numeroNivel = 1;
        this.vidasRestantes = 3;
        this.pausado = false;
        this.juegoTerminado = false;
        this.nivelCompletado = false;
        this.temporizador = new ManejadorTiempo();
        
        this.obstaculosPorNivel = new ArrayList<TipoObstaculoMapa>();
        this.frutasPorNivel = new ArrayList<TipoFruta[]>();
        this.enemigoPorNivel = new ArrayList<TipoEnemigo>();
        
        // Configuración por defecto de 3 niveles
        configuracionPorDefecto();
        
        // Iniciar primer nivel
        iniciarNivel(1);
    }

    /**
     * Constructor con modalidad enum y perfiles IA
     */
    public GameEngine(Modalidad modalidad, PerfilMaquina perfilIA1, PerfilMaquina perfilIA2) throws GameException {
        this.modalidad = convertirModalidad(modalidad);
        this.colorHelado = "Vainilla";
        this.perfilIA1 = perfilIA1;
        this.perfilIA2 = perfilIA2;
        this.puntajeTotal = 0;
        this.numeroNivel = 1;
        this.vidasRestantes = 3;
        this.pausado = false;
        this.juegoTerminado = false;
        this.nivelCompletado = false;
        this.temporizador = new ManejadorTiempo();
        
        this.obstaculosPorNivel = new ArrayList<TipoObstaculoMapa>();
        this.frutasPorNivel = new ArrayList<TipoFruta[]>();
        this.enemigoPorNivel = new ArrayList<TipoEnemigo>();
        
        configuracionPorDefecto();
        iniciarNivel(1);
    }

    /**
     * Convierte modalidad enum a String
     */
    private String convertirModalidad(Modalidad mod) {
        if (mod == Modalidad.PLAYER) return "Player";
        if (mod == Modalidad.PVSP) return "PvsP";
        if (mod == Modalidad.PVSM) return "PvsM";
        if (mod == Modalidad.MVSM) return "MvsM";
        return "Player";
    }

    /**
     * Configuración por defecto de 3 niveles
     */
    private void configuracionPorDefecto() {
        // Nivel 1: Hielo, Uvas y Bananos, Troll
        setConfiguracionNivel(0, TipoObstaculoMapa.HIELO, TipoFruta.UVA, TipoFruta.BANANO, TipoEnemigo.TROLL);
        
        // Nivel 2: Baldosas calientes, Cerezas y Piñas, Maceta
        setConfiguracionNivel(1, TipoObstaculoMapa.BALDOSA_CALIENTE, TipoFruta.CEREZA, TipoFruta.PINA, TipoEnemigo.MACETA);
        
        // Nivel 3: Fogatas, Piñas y Cactus, Calamar
        setConfiguracionNivel(2, TipoObstaculoMapa.FOGATA, TipoFruta.PINA, TipoFruta.CACTUS, TipoEnemigo.CALAMAR);
    }

    // ==================== CONFIGURACIÓN ====================

    public void setConfiguracionNivel(int nivelIndex, TipoObstaculoMapa obstaculo, 
                                     TipoFruta fruta1, TipoFruta fruta2, TipoEnemigo enemigo) {
        ensureSize(nivelIndex + 1);
        obstaculosPorNivel.set(nivelIndex, obstaculo);
        frutasPorNivel.set(nivelIndex, new TipoFruta[]{fruta1, fruta2});
        enemigoPorNivel.set(nivelIndex, enemigo);
    }

    private void ensureSize(int size) {
        while (obstaculosPorNivel.size() < size) {
            obstaculosPorNivel.add(TipoObstaculoMapa.HIELO);
        }
        while (frutasPorNivel.size() < size) {
            frutasPorNivel.add(new TipoFruta[]{TipoFruta.UVA, TipoFruta.BANANO});
        }
        while (enemigoPorNivel.size() < size) {
            enemigoPorNivel.add(TipoEnemigo.TROLL);
        }
    }

    // ==================== INICIO DE NIVEL ====================

    public void iniciarNivel(int numeroNivel) throws GameException {
        this.numeroNivel = numeroNivel;
        this.nivelCompletado = false;

        // Obtener configuración de este nivel
        ensureSize(numeroNivel);
        TipoObstaculoMapa obstaculo = obstaculosPorNivel.get(numeroNivel - 1);
        TipoFruta[] frutas = frutasPorNivel.get(numeroNivel - 1);
        TipoEnemigo enemigo = enemigoPorNivel.get(numeroNivel - 1);

        // Crear helado principal
        String sabor = colorHelado != null ? colorHelado : "Vainilla";
        helado = new Helado(7, 7, null, sabor);

        // Crear segundo helado si es necesario
        if (modalidad.equals("PvsP") || modalidad.equals("PvsM") || modalidad.equals("MvsM")) {
            helado2 = new Helado(7, 8, null, "Chocolate");
        } else {
            helado2 = null;
        }

        // Crear nivel
        nivelActual = new Nivel(numeroNivel, helado, obstaculo, frutas[0], frutas[1], enemigo);
        
        // Asignar mapa a los helados
        helado.setMapa(nivelActual.getMapa());
        if (helado2 != null) {
            helado2.setMapa(nivelActual.getMapa());
        }

        // Reiniciar temporizador
        temporizador.reiniciar();
        pausado = false;
    }

    // ==================== ACTUALIZACIÓN ====================

    public void actualizar() {
        if (pausado || juegoTerminado || nivelActual == null) return;

        // Actualizar temporizador
        temporizador.actualizar();

        // Aplicar IA si corresponde
        aplicarIA();

        // Actualizar nivel
        nivelActual.actualizar();

        // Verificar colisiones y reglas
        verificarReglas(helado);
        if (helado2 != null) {
            verificarReglas(helado2);
        }

        // Verificar si nivel completado
        if (nivelActual.nivelCompletado()) {
            nivelCompletado = true;
        }

        // Verificar tiempo agotado
        if (temporizador.tiempoAgotado()) {
            perderVida();
        }
    }

    private void verificarReglas(Helado h) {
        if (h == null || !h.isVivo()) return;

        // Colisión con enemigos
        if (nivelActual.verificarColisionEnemigos(h)) {
            h.morir();
            perderVida();
            return;
        }

        // Colisión con fogatas
        if (nivelActual.verificarColisionFogatas(h)) {
            h.morir();
            perderVida();
            return;
        }

        // Recolección de frutas
        Fruta f = nivelActual.verificarColisionFrutas(h);
        if (f != null && f.isActiva()) {
            if (!(f instanceof Cactus) || ((Cactus) f).puedeSerRecolectado()) {
                f.recolectar();
                puntajeTotal += f.getPuntos();
            }
        }
    }

    private void perderVida() {
        vidasRestantes--;
        if (vidasRestantes <= 0) {
            juegoTerminado = true;
        } else {
            try {
                iniciarNivel(1); // Reiniciar al nivel 1
            } catch (GameException e) {
                juegoTerminado = true;
            }
        }
    }

    // ==================== IA ====================

    private int iaFrameCounter = 0;

    private void aplicarIA() {
        iaFrameCounter++;

        if (modalidad.equals("MvsM") && helado != null && perfilIA1 != null) {
            if (iaFrameCounter % 6 == 0) {
                moverIA(helado, perfilIA1);
            }
        }

        if ((modalidad.equals("PvsM") || modalidad.equals("MvsM")) && helado2 != null && perfilIA2 != null) {
            if (iaFrameCounter % 6 == 0) {
                moverIA(helado2, perfilIA2);
            }
        }
    }

    private void moverIA(Helado h, PerfilMaquina perfil) {
        if (h == null || nivelActual == null || perfil == null) return;

        if (perfil == PerfilMaquina.HUNGRY) {
            moverHaciaFrutaMasCercana(h);
        } else if (perfil == PerfilMaquina.FEARFUL) {
            alejarseDeEnemigoMasCercano(h);
            if (iaFrameCounter % 30 == 0) h.crearBloques();
        } else if (perfil == PerfilMaquina.EXPERT) {
            if (enemigoCerca(h, 3)) {
                h.romperBloques();
                alejarseDeEnemigoMasCercano(h);
            } else {
                moverHaciaFrutaMasCercana(h);
            }
        }
    }

    private boolean enemigoCerca(Helado h, int rango) {
        for (Enemigo e : nivelActual.getEnemigos()) {
            int distancia = Math.abs(e.getX() - h.getX()) + Math.abs(e.getY() - h.getY());
            if (distancia <= rango) return true;
        }
        return false;
    }

    private void moverHaciaFrutaMasCercana(Helado h) {
        Fruta objetivo = null;
        int mejor = Integer.MAX_VALUE;
        
        for (Fruta f : nivelActual.getFrutas()) {
            if (!f.isActiva()) continue;
            int d = Math.abs(f.getX() - h.getX()) + Math.abs(f.getY() - h.getY());
            if (d < mejor) {
                mejor = d;
                objetivo = f;
            }
        }
        
        if (objetivo == null) return;
        
        int dx = objetivo.getX() - h.getX();
        int dy = objetivo.getY() - h.getY();
        
        if (Math.abs(dx) > Math.abs(dy)) {
            h.mover(dx > 0 ? "derecha" : "izquierda");
        } else if (dy != 0) {
            h.mover(dy > 0 ? "abajo" : "arriba");
        }
    }

    private void alejarseDeEnemigoMasCercano(Helado h) {
        Enemigo objetivo = null;
        int mejor = Integer.MAX_VALUE;
        
        for (Enemigo e : nivelActual.getEnemigos()) {
            int d = Math.abs(e.getX() - h.getX()) + Math.abs(e.getY() - h.getY());
            if (d < mejor) {
                mejor = d;
                objetivo = e;
            }
        }
        
        if (objetivo == null) return;
        
        int dx = objetivo.getX() - h.getX();
        int dy = objetivo.getY() - h.getY();
        
        if (Math.abs(dx) > Math.abs(dy)) {
            h.mover(dx > 0 ? "izquierda" : "derecha");
        } else if (dy != 0) {
            h.mover(dy > 0 ? "arriba" : "abajo");
        }
    }

    // ==================== CONTROL DEL JUEGO ====================

    public void moverHelado(String direccion) {
        if (helado != null && helado.isVivo()) {
            helado.mover(direccion);
        }
    }

    public void accionBloque() {
        if (helado != null && helado.isVivo()) {
            helado.crearBloques();
        }
    }

    public void siguienteNivel() throws GameException {
        int siguiente = numeroNivel + 1;
        if (siguiente > 3) {
            juegoTerminado = true;
        } else {
            iniciarNivel(siguiente);
        }
    }

    public void reiniciarJuego() throws GameException {
        puntajeTotal = 0;
        vidasRestantes = 3;
        juegoTerminado = false;
        nivelCompletado = false;
        iniciarNivel(1);
    }

    // ==================== GETTERS ====================

    public Nivel getNivel() { 
        return nivelActual; 
    }

    public Nivel getNivelActual() { 
        return nivelActual; 
    }

    // CORREGIDO: Cambiado de getNivelActual() a getNumeroNivel()
    public int getNumeroNivel() { 
        return numeroNivel; 
    }

    public int getPuntaje() { 
        return puntajeTotal; 
    }

    public int getPuntajeTotal() { 
        return puntajeTotal; 
    }

    public int getVidasRestantes() { 
        return vidasRestantes; 
    }

    public boolean isPausado() { 
        return pausado; 
    }

    public boolean isJuegoTerminado() { 
        return juegoTerminado; 
    }

    public boolean isGameOver() { 
        return juegoTerminado; 
    }

    public boolean isNivelCompletado() { 
        return nivelCompletado; 
    }

    public Helado getHelado() { 
        return helado; 
    }

    public Helado getHelado1() { 
        return helado; 
    }

    public Helado getHelado2() { 
        return helado2; 
    }

    public ManejadorTiempo getTemporizador() { 
        return temporizador; 
    }

    public String getModalidad() { 
        return modalidad; 
    }
    
    public int getFrutasRecolectadas() {
        if (nivelActual == null) return 0;
        return nivelActual.getFrutasRecolectadas();
    }
    
    public String getTiempoRestante() {
        return temporizador.getTiempoFormateado();
    }
    
    public boolean juegoCompletado() {
        return numeroNivel >= 3 && nivelCompletado;
    }

    public void pausar() { 
        pausado = true; 
    }
    
    public void reanudar() { 
        pausado = false; 
    }
    
    public void terminar() { 
        juegoTerminado = true; 
    }
}