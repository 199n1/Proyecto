package logic;

/**
 * Perfiles de comportamiento para máquinas.
 */
public enum PerfilMaquina {
    HUNGRY,
    FEARFUL,
    EXPERT
}