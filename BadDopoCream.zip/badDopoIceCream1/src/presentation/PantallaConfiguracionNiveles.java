package presentation;

import domain.*;
import logic.GameEngine;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Pantalla para configurar los 3 niveles del juego
 * Con navegacion ANTERIOR y SIGUIENTE entre niveles
 */
public class PantallaConfiguracionNiveles extends JFrame {
    
    private String modalidad;
    private String saborHelado;
    private int nivelActual;
    
    // Configuracion de cada nivel
    private TipoObstaculoMapa[] obstaculosSeleccionados;
    private TipoFruta[][] frutasSeleccionadas;
    private TipoEnemigo[] enemigosSeleccionados;
    
    // Componentes
    private JLabel lblNivel;
    private JLabel lblDescripcionMapa;
    private JComboBox<TipoObstaculoMapa> cmbObstaculo;
    private JComboBox<TipoFruta> cmbFruta1;
    private JComboBox<TipoFruta> cmbFruta2;
    private JComboBox<TipoEnemigo> cmbEnemigo;
    private JButton btnAnterior;
    private JButton btnSiguiente;
    private JButton btnJugar;
    
    public PantallaConfiguracionNiveles(String modalidad, String saborHelado) {
        this.modalidad = modalidad;
        this.saborHelado = saborHelado;
        this.nivelActual = 1;
        
        // Inicializar arrays
        this.obstaculosSeleccionados = new TipoObstaculoMapa[3];
        this.frutasSeleccionadas = new TipoFruta[3][2];
        this.enemigosSeleccionados = new TipoEnemigo[3];
        
        inicializarConfiguracionDefecto();
        configurarVentana();
        inicializarComponentes();
        actualizarVista();
    }
    
    private void inicializarConfiguracionDefecto() {
        // Nivel 1: Hielo, Uva y Banano, Troll
        obstaculosSeleccionados[0] = TipoObstaculoMapa.HIELO;
        frutasSeleccionadas[0][0] = TipoFruta.UVA;
        frutasSeleccionadas[0][1] = TipoFruta.BANANO;
        enemigosSeleccionados[0] = TipoEnemigo.TROLL;
        
        // Nivel 2: Baldosas, Cereza y Piña, Maceta
        obstaculosSeleccionados[1] = TipoObstaculoMapa.BALDOSA_CALIENTE;
        frutasSeleccionadas[1][0] = TipoFruta.CEREZA;
        frutasSeleccionadas[1][1] = TipoFruta.PINA;
        enemigosSeleccionados[1] = TipoEnemigo.MACETA;
        
        // Nivel 3: Fogata, Piña y Cactus, Calamar
        obstaculosSeleccionados[2] = TipoObstaculoMapa.FOGATA;
        frutasSeleccionadas[2][0] = TipoFruta.PINA;
        frutasSeleccionadas[2][1] = TipoFruta.CACTUS;
        enemigosSeleccionados[2] = TipoEnemigo.CALAMAR;
    }
    
    private void configurarVentana() {
        setTitle("Configurar Niveles - Bad DOPO Cream");
        setSize(550, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
    }
    
    private void inicializarComponentes() {
        JPanel panelPrincipal = new JPanel();
        panelPrincipal.setLayout(null);
        panelPrincipal.setBackground(new Color(200, 230, 255));
        
        // Titulo
        JLabel titulo = new JLabel("CONFIGURAR NIVELES", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 26));
        titulo.setForeground(new Color(25, 25, 112));
        titulo.setBounds(50, 15, 450, 35);
        panelPrincipal.add(titulo);
        
        // Indicador de nivel
        lblNivel = new JLabel("NIVEL 1", SwingConstants.CENTER);
        lblNivel.setFont(new Font("Arial", Font.BOLD, 22));
        lblNivel.setForeground(new Color(220, 20, 60));
        lblNivel.setBounds(175, 55, 200, 30);
        panelPrincipal.add(lblNivel);
        
        // Descripcion del mapa
        lblDescripcionMapa = new JLabel("", SwingConstants.CENTER);
        lblDescripcionMapa.setFont(new Font("Arial", Font.ITALIC, 12));
        lblDescripcionMapa.setForeground(new Color(100, 100, 100));
        lblDescripcionMapa.setBounds(50, 90, 450, 20);
        panelPrincipal.add(lblDescripcionMapa);
        
        int yInicial = 130;
        int espaciado = 70;
        
        // Obstaculo
        agregarCampo(panelPrincipal, "Tipo de Mapa:", yInicial);
        cmbObstaculo = new JComboBox<TipoObstaculoMapa>(TipoObstaculoMapa.values());
        cmbObstaculo.setBounds(200, yInicial, 280, 30);
        cmbObstaculo.setFont(new Font("Arial", Font.PLAIN, 14));
        cmbObstaculo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                actualizarDescripcionMapa();
            }
        });
        panelPrincipal.add(cmbObstaculo);
        
        // Fruta 1
        agregarCampo(panelPrincipal, "Fruta 1:", yInicial + espaciado);
        cmbFruta1 = new JComboBox<TipoFruta>(TipoFruta.values());
        cmbFruta1.setBounds(200, yInicial + espaciado, 280, 30);
        cmbFruta1.setFont(new Font("Arial", Font.PLAIN, 14));
        panelPrincipal.add(cmbFruta1);
        
        // Fruta 2
        agregarCampo(panelPrincipal, "Fruta 2:", yInicial + espaciado * 2);
        cmbFruta2 = new JComboBox<TipoFruta>(TipoFruta.values());
        cmbFruta2.setBounds(200, yInicial + espaciado * 2, 280, 30);
        cmbFruta2.setFont(new Font("Arial", Font.PLAIN, 14));
        panelPrincipal.add(cmbFruta2);
        
        // Enemigo
        agregarCampo(panelPrincipal, "Enemigo:", yInicial + espaciado * 3);
        cmbEnemigo = new JComboBox<TipoEnemigo>(TipoEnemigo.values());
        cmbEnemigo.setBounds(200, yInicial + espaciado * 3, 280, 30);
        cmbEnemigo.setFont(new Font("Arial", Font.PLAIN, 14));
        panelPrincipal.add(cmbEnemigo);
        
        // Botones de navegacion
        btnAnterior = new JButton("← ANTERIOR");
        btnAnterior.setFont(new Font("Arial", Font.BOLD, 14));
        btnAnterior.setBounds(70, 450, 150, 40);
        btnAnterior.setBackground(new Color(200, 200, 200));
        btnAnterior.setFocusPainted(false);
        btnAnterior.setEnabled(false);
        btnAnterior.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cambiarNivel(-1);
            }
        });
        panelPrincipal.add(btnAnterior);
        
        btnSiguiente = new JButton("SIGUIENTE →");
        btnSiguiente.setFont(new Font("Arial", Font.BOLD, 14));
        btnSiguiente.setBounds(330, 450, 150, 40);
        btnSiguiente.setBackground(new Color(100, 149, 237));
        btnSiguiente.setForeground(Color.WHITE);
        btnSiguiente.setFocusPainted(false);
        btnSiguiente.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cambiarNivel(1);
            }
        });
        panelPrincipal.add(btnSiguiente);
        
        // Boton JUGAR
        btnJugar = new JButton("JUGAR");
        btnJugar.setFont(new Font("Arial", Font.BOLD, 20));
        btnJugar.setBounds(175, 510, 200, 50);
        btnJugar.setBackground(new Color(60, 179, 113));
        btnJugar.setForeground(Color.WHITE);
        btnJugar.setFocusPainted(false);
        btnJugar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                iniciarJuego();
            }
        });
        panelPrincipal.add(btnJugar);
        
        add(panelPrincipal);
    }
    
    private void agregarCampo(JPanel panel, String texto, int y) {
        JLabel lbl = new JLabel(texto);
        lbl.setFont(new Font("Arial", Font.BOLD, 15));
        lbl.setBounds(60, y, 130, 30);
        panel.add(lbl);
    }
    
    private void cambiarNivel(int direccion) {
        // Guardar configuracion actual
        guardarConfiguracion();
        
        // Cambiar nivel
        nivelActual = nivelActual + direccion;
        if (nivelActual < 1) nivelActual = 1;
        if (nivelActual > 3) nivelActual = 3;
        
        // Actualizar vista
        actualizarVista();
    }
    
    private void guardarConfiguracion() {
        int idx = nivelActual - 1;
        
        obstaculosSeleccionados[idx] = (TipoObstaculoMapa) cmbObstaculo.getSelectedItem();
        frutasSeleccionadas[idx][0] = (TipoFruta) cmbFruta1.getSelectedItem();
        frutasSeleccionadas[idx][1] = (TipoFruta) cmbFruta2.getSelectedItem();
        enemigosSeleccionados[idx] = (TipoEnemigo) cmbEnemigo.getSelectedItem();
    }
    
    private void actualizarVista() {
        int idx = nivelActual - 1;
        
        lblNivel.setText("NIVEL " + nivelActual);
        
        cmbObstaculo.setSelectedItem(obstaculosSeleccionados[idx]);
        cmbFruta1.setSelectedItem(frutasSeleccionadas[idx][0]);
        cmbFruta2.setSelectedItem(frutasSeleccionadas[idx][1]);
        cmbEnemigo.setSelectedItem(enemigosSeleccionados[idx]);
        
        btnAnterior.setEnabled(nivelActual > 1);
        btnSiguiente.setEnabled(nivelActual < 3);
        
        actualizarDescripcionMapa();
    }
    
    private void actualizarDescripcionMapa() {
        TipoObstaculoMapa tipo = (TipoObstaculoMapa) cmbObstaculo.getSelectedItem();
        String descripcion = "";
        
        if (tipo == TipoObstaculoMapa.HIELO) {
            descripcion = "Mapa con bloques de hielo que puedes crear y romper";
        } else if (tipo == TipoObstaculoMapa.BALDOSA_CALIENTE) {
            descripcion = "Mapa con baldosas calientes que derriten bloques de hielo";
        } else if (tipo == TipoObstaculoMapa.FOGATA) {
            descripcion = "Mapa con fogatas que eliminan al helado si las toca";
        }
        
        lblDescripcionMapa.setText(descripcion);
    }
    
    private void iniciarJuego() {
        // Guardar configuracion del nivel actual
        guardarConfiguracion();
        
        try {
            // Crear motor del juego
            GameEngine engine = new GameEngine(modalidad, saborHelado);
            
            // Aplicar configuracion personalizada
            for (int i = 0; i < 3; i++) {
                engine.setConfiguracionNivel(i, obstaculosSeleccionados[i], 
                    frutasSeleccionadas[i][0], frutasSeleccionadas[i][1], 
                    enemigosSeleccionados[i]);
            }
            
            // Reiniciar para aplicar configuracion
            engine.reiniciarJuego();
            
            dispose();
            
            // Abrir ventana de juego
            VentanaJuego ventana = new VentanaJuego(modalidad, saborHelado);
            ventana.setVisible(true);
            
        } catch (GameException e) {
            JOptionPane.showMessageDialog(this, 
                "Error al iniciar el juego: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}