package presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Pantalla para seleccionar la modalidad del juego
 */
public class PantallaSeleccionModalidad extends JFrame {
    
    private String modalidadSeleccionada;
    
    public PantallaSeleccionModalidad() {
        this.modalidadSeleccionada = null;
        configurarVentana();
        inicializarComponentes();
    }
    
    private void configurarVentana() {
        setTitle("Seleccionar Modalidad - Bad DOPO Cream");
        setSize(550, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
    }
    
    private void inicializarComponentes() {
        JPanel panelPrincipal = new JPanel();
        panelPrincipal.setLayout(new BoxLayout(panelPrincipal, BoxLayout.Y_AXIS));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        panelPrincipal.setBackground(new Color(200, 230, 255));
        
        // Titulo
        JLabel titulo = new JLabel("SELECCIONA LA MODALIDAD");
        titulo.setFont(new Font("Arial", Font.BOLD, 26));
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        titulo.setForeground(new Color(25, 25, 112));
        panelPrincipal.add(titulo);
        
        panelPrincipal.add(Box.createRigidArea(new Dimension(0, 30)));
        
        // Boton Player
        JButton btnPlayer = crearBotonModalidad("PLAYER", 
            "Un jugador controla un helado");
        btnPlayer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                seleccionarModalidad("Player");
            }
        });
        panelPrincipal.add(btnPlayer);
        panelPrincipal.add(Box.createRigidArea(new Dimension(0, 15)));
        
        // Boton Player vs Player
        JButton btnPvsP = crearBotonModalidad("PLAYER vs PLAYER",
            "Dos jugadores compiten por mayor puntuación");
        btnPvsP.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                seleccionarModalidad("PvsP");
            }
        });
        panelPrincipal.add(btnPvsP);
        panelPrincipal.add(Box.createRigidArea(new Dimension(0, 15)));
        
        // Boton Player vs Machine
        JButton btnPvsM = crearBotonModalidad("PLAYER vs MACHINE",
            "Jugador contra máquina inteligente");
        btnPvsM.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                seleccionarModalidad("PvsM");
            }
        });
        panelPrincipal.add(btnPvsM);
        panelPrincipal.add(Box.createRigidArea(new Dimension(0, 15)));
        
        // Boton Machine vs Machine
        JButton btnMvsM = crearBotonModalidad("MACHINE vs MACHINE",
            "Dos máquinas compiten automáticamente");
        btnMvsM.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                seleccionarModalidad("MvsM");
            }
        });
        panelPrincipal.add(btnMvsM);
        
        panelPrincipal.add(Box.createRigidArea(new Dimension(0, 30)));
        
        // Boton Atras
        JButton btnAtras = new JButton("← ATRÁS");
        btnAtras.setFont(new Font("Arial", Font.BOLD, 14));
        btnAtras.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnAtras.setMaximumSize(new Dimension(150, 40));
        btnAtras.setBackground(new Color(200, 200, 200));
        btnAtras.setFocusPainted(false);
        btnAtras.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                volverAlMenu();
            }
        });
        panelPrincipal.add(btnAtras);
        
        add(panelPrincipal);
    }
    
    private JButton crearBotonModalidad(String titulo, String descripcion) {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout(10, 5));
        panel.setBackground(new Color(70, 130, 180));
        panel.setBorder(BorderFactory.createEmptyBorder(12, 15, 12, 15));
        
        JLabel lblTitulo = new JLabel(titulo);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 18));
        lblTitulo.setForeground(Color.WHITE);
        
        JLabel lblDesc = new JLabel(descripcion);
        lblDesc.setFont(new Font("Arial", Font.ITALIC, 12));
        lblDesc.setForeground(new Color(230, 230, 230));
        
        panel.add(lblTitulo, BorderLayout.NORTH);
        panel.add(lblDesc, BorderLayout.CENTER);
        
        JButton boton = new JButton();
        boton.setLayout(new BorderLayout());
        boton.add(panel);
        boton.setAlignmentX(Component.CENTER_ALIGNMENT);
        boton.setMaximumSize(new Dimension(450, 70));
        boton.setFocusPainted(false);
        boton.setBorderPainted(false);
        boton.setContentAreaFilled(false);
        
        return boton;
    }
    
    private void seleccionarModalidad(String modalidad) {
        modalidadSeleccionada = modalidad;
        dispose();
        PantallaSeleccionSabor pantalla = new PantallaSeleccionSabor(modalidadSeleccionada);
        pantalla.setVisible(true);
    }
    
    private void volverAlMenu() {
        dispose();
        MenuPrincipal menu = new MenuPrincipal();
        menu.setVisible(true);
    }
}