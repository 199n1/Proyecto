package presentation;

import javax.swing.*;
import java.awt.*;

/**
 * Clase que representa el HUD (Head-Up Display) del juego
 * Muestra informacion sobre frutas, tiempo, puntaje, vidas y nivel
 */
public class HUD extends JPanel {
    
    private JLabel lblNivel;
    private JLabel lblVidas;
    private JLabel lblFrutas;
    private JLabel lblTiempo;
    private JLabel lblPuntaje;
    
    /**
     * Constructor del HUD
     */
    public HUD() {
        configurarPanel();
        inicializarComponentes();
    }
    
    /**
     * Configura las propiedades del panel
     */
    private void configurarPanel() {
        setPreferredSize(new Dimension(600, 60));
        setBackground(new Color(100, 150, 200));
        setLayout(new FlowLayout(FlowLayout.CENTER, 20, 15));
    }
    
    /**
     * Inicializa los componentes del HUD
     */
    private void inicializarComponentes() {
        Font fuente = new Font("Arial", Font.BOLD, 14);
        Color colorTexto = Color.WHITE;
        
        // Label de nivel
        lblNivel = new JLabel("Nivel: 1");
        lblNivel.setFont(fuente);
        lblNivel.setForeground(colorTexto);
        add(lblNivel);
        
        // Label de vidas
        lblVidas = new JLabel("Vidas: ♥♥♥");
        lblVidas.setFont(fuente);
        lblVidas.setForeground(colorTexto);
        add(lblVidas);
        
        // Label de frutas
        lblFrutas = new JLabel("Frutas: 0/16");
        lblFrutas.setFont(fuente);
        lblFrutas.setForeground(colorTexto);
        add(lblFrutas);
        
        // Label de tiempo
        lblTiempo = new JLabel("Tiempo: 3:00");
        lblTiempo.setFont(fuente);
        lblTiempo.setForeground(colorTexto);
        add(lblTiempo);
        
        // Label de puntaje
        lblPuntaje = new JLabel("Puntaje: 0");
        lblPuntaje.setFont(fuente);
        lblPuntaje.setForeground(colorTexto);
        add(lblPuntaje);
    }
    
    /**
     * Actualiza el nivel actual
     */
    public void actualizarNivel(int nivel) {
        lblNivel.setText("Nivel: " + nivel);
    }
    
    /**
     * Actualiza las vidas restantes
     */
    public void actualizarVidas(int vidas) {
        String corazones = "";
        for (int i = 0; i < vidas; i++) {
            corazones += "♥";
        }
        // Mostrar corazones grises para vidas perdidas
        for (int i = vidas; i < 3; i++) {
            corazones += "♡";
        }
        lblVidas.setText("Vidas: " + corazones);
        
        // Cambiar color si quedan pocas vidas
        if (vidas <= 1) {
            lblVidas.setForeground(new Color(255, 100, 100));
        } else {
            lblVidas.setForeground(Color.WHITE);
        }
    }
    
    /**
     * Actualiza el contador de frutas recolectadas
     */
    public void actualizarFrutas(int recolectadas, int totales) {
        lblFrutas.setText("Frutas: " + recolectadas + "/" + totales);
    }
    
    /**
     * Actualiza el tiempo restante
     */
    public void actualizarTiempo(String tiempoFormateado) {
        lblTiempo.setText("Tiempo: " + tiempoFormateado);
        
        // Cambiar color si queda poco tiempo
        String[] partes = tiempoFormateado.split(":");
        if (partes.length == 2) {
            int minutos = Integer.parseInt(partes[0]);
            int segundos = Integer.parseInt(partes[1]);
            int totalSegundos = minutos * 60 + segundos;
            
            if (totalSegundos < 30) {
                lblTiempo.setForeground(new Color(255, 100, 100));
            } else {
                lblTiempo.setForeground(Color.WHITE);
            }
        }
    }
    
    /**
     * Actualiza el puntaje
     */
    public void actualizarPuntaje(int puntaje) {
        lblPuntaje.setText("Puntaje: " + puntaje);
    }
}