package presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Pantalla para seleccionar el sabor del helado
 */
public class PantallaSeleccionSabor extends JFrame {
    
    private String modalidad;
    private String saborSeleccionado;
    
    public PantallaSeleccionSabor(String modalidad) {
        this.modalidad = modalidad;
        this.saborSeleccionado = null;
        configurarVentana();
        inicializarComponentes();
    }
    
    private void configurarVentana() {
        setTitle("Seleccionar Sabor - Bad DOPO Cream");
        setSize(500, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
    }
    
    private void inicializarComponentes() {
        JPanel panelPrincipal = new JPanel();
        panelPrincipal.setLayout(new BoxLayout(panelPrincipal, BoxLayout.Y_AXIS));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        panelPrincipal.setBackground(new Color(200, 230, 255));
        
        // Titulo
        JLabel titulo = new JLabel("ELIGE TU SABOR DE HELADO");
        titulo.setFont(new Font("Arial", Font.BOLD, 26));
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        titulo.setForeground(new Color(25, 25, 112));
        panelPrincipal.add(titulo);
        
        panelPrincipal.add(Box.createRigidArea(new Dimension(0, 10)));
        
        // Mostrar modalidad seleccionada
        JLabel lblModalidad = new JLabel("Modalidad: " + obtenerNombreModalidad());
        lblModalidad.setFont(new Font("Arial", Font.ITALIC, 14));
        lblModalidad.setAlignmentX(Component.CENTER_ALIGNMENT);
        lblModalidad.setForeground(new Color(70, 70, 70));
        panelPrincipal.add(lblModalidad);
        
        panelPrincipal.add(Box.createRigidArea(new Dimension(0, 30)));
        
        // Boton Vainilla
        JButton btnVainilla = crearBotonSabor("VAINILLA", "🍦", 
            new Color(255, 250, 240), Color.BLACK);
        btnVainilla.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                seleccionarSabor("Vainilla");
            }
        });
        panelPrincipal.add(btnVainilla);
        panelPrincipal.add(Box.createRigidArea(new Dimension(0, 15)));
        
        // Boton Chocolate
        JButton btnChocolate = crearBotonSabor("CHOCOLATE", "🍫", 
            new Color(139, 69, 19), Color.WHITE);
        btnChocolate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                seleccionarSabor("Chocolate");
            }
        });
        panelPrincipal.add(btnChocolate);
        panelPrincipal.add(Box.createRigidArea(new Dimension(0, 15)));
        
        // Boton Fresa
        JButton btnFresa = crearBotonSabor("FRESA", "🍓", 
            new Color(255, 182, 193), Color.BLACK);
        btnFresa.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                seleccionarSabor("Fresa");
            }
        });
        panelPrincipal.add(btnFresa);
        
        panelPrincipal.add(Box.createRigidArea(new Dimension(0, 30)));
        
        // Boton Atras
        JButton btnAtras = new JButton("← ATRÁS");
        btnAtras.setFont(new Font("Arial", Font.BOLD, 14));
        btnAtras.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnAtras.setMaximumSize(new Dimension(150, 40));
        btnAtras.setBackground(new Color(200, 200, 200));
        btnAtras.setFocusPainted(false);
        btnAtras.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                volverAtras();
            }
        });
        panelPrincipal.add(btnAtras);
        
        add(panelPrincipal);
    }
    
    private JButton crearBotonSabor(String texto, String emoji, Color colorFondo, Color colorTexto) {
        JButton boton = new JButton(emoji + "  " + texto);
        boton.setFont(new Font("Arial", Font.BOLD, 22));
        boton.setAlignmentX(Component.CENTER_ALIGNMENT);
        boton.setMaximumSize(new Dimension(320, 60));
        boton.setBackground(colorFondo);
        boton.setForeground(colorTexto);
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        return boton;
    }
    
    private String obtenerNombreModalidad() {
        if (modalidad.equals("Player")) return "Un Jugador";
        if (modalidad.equals("PvsP")) return "Jugador vs Jugador";
        if (modalidad.equals("PvsM")) return "Jugador vs Máquina";
        if (modalidad.equals("MvsM")) return "Máquina vs Máquina";
        return modalidad;
    }
    
    private void seleccionarSabor(String sabor) {
        saborSeleccionado = sabor;
        dispose();
        PantallaConfiguracionNiveles pantalla = new PantallaConfiguracionNiveles(modalidad, saborSeleccionado);
        pantalla.setVisible(true);
    }
    
    private void volverAtras() {
        dispose();
        PantallaSeleccionModalidad pantalla = new PantallaSeleccionModalidad();
        pantalla.setVisible(true);
    }
}