package presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Menu principal del juego Bad DOPO Cream
 * Version mejorada con solo boton INICIAR
 */
public class MenuPrincipal extends JFrame {
    
    private JButton btnIniciar;
    private JButton btnCargar;
    private JButton btnRanking;
    private JButton btnSalir;
    
    public MenuPrincipal() {
        configurarVentana();
        inicializarComponentes();
    }
    
    private void configurarVentana() {
        setTitle("Bad DOPO Cream");
        setSize(500, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
    }
    
    private void inicializarComponentes() {
        JPanel panelPrincipal = new JPanel();
        panelPrincipal.setLayout(new BoxLayout(panelPrincipal, BoxLayout.Y_AXIS));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));
        panelPrincipal.setBackground(new Color(200, 230, 255));
        
        // Titulo
        JLabel titulo = new JLabel("BAD DOPO CREAM");
        titulo.setFont(new Font("Arial", Font.BOLD, 40));
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        titulo.setForeground(new Color(25, 25, 112));
        panelPrincipal.add(titulo);
        
        panelPrincipal.add(Box.createRigidArea(new Dimension(0, 10)));
        
        // Icono de helado (texto)
        JLabel icono = new JLabel("🍦");
        icono.setFont(new Font("Arial", Font.PLAIN, 60));
        icono.setAlignmentX(Component.CENTER_ALIGNMENT);
        panelPrincipal.add(icono);
        
        panelPrincipal.add(Box.createRigidArea(new Dimension(0, 10)));
        
        // Subtitulo
        JLabel subtitulo = new JLabel("¡Recolecta frutas y evita enemigos!");
        subtitulo.setFont(new Font("Arial", Font.ITALIC, 16));
        subtitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        subtitulo.setForeground(new Color(70, 70, 70));
        panelPrincipal.add(subtitulo);
        
        panelPrincipal.add(Box.createRigidArea(new Dimension(0, 40)));
        
        // Boton INICIAR (grande y centrado)
        btnIniciar = new JButton("INICIAR");
        btnIniciar.setFont(new Font("Arial", Font.BOLD, 28));
        btnIniciar.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnIniciar.setMaximumSize(new Dimension(250, 70));
        btnIniciar.setBackground(new Color(60, 179, 113));
        btnIniciar.setForeground(Color.WHITE);
        btnIniciar.setFocusPainted(false);
        btnIniciar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                iniciarJuego();
            }
        });
        panelPrincipal.add(btnIniciar);
        
        panelPrincipal.add(Box.createRigidArea(new Dimension(0, 30)));
        
        // Panel de botones secundarios
        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new GridLayout(1, 3, 15, 0));
        panelBotones.setBackground(new Color(200, 230, 255));
        panelBotones.setMaximumSize(new Dimension(400, 45));
        
        btnCargar = crearBotonSecundario("CARGAR");
        btnCargar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cargarPartida();
            }
        });
        
        btnRanking = crearBotonSecundario("RANKING");
        btnRanking.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mostrarRanking();
            }
        });
        
        btnSalir = crearBotonSecundario("SALIR");
        btnSalir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        
        panelBotones.add(btnCargar);
        panelBotones.add(btnRanking);
        panelBotones.add(btnSalir);
        
        panelPrincipal.add(panelBotones);
        
        panelPrincipal.add(Box.createRigidArea(new Dimension(0, 20)));
        
        // Creditos
        JLabel creditos = new JLabel("DOPO 2025-2 | Escuela Colombiana de Ingeniería");
        creditos.setFont(new Font("Arial", Font.ITALIC, 11));
        creditos.setAlignmentX(Component.CENTER_ALIGNMENT);
        creditos.setForeground(new Color(100, 100, 100));
        panelPrincipal.add(creditos);
        
        add(panelPrincipal);
    }
    
    private JButton crearBotonSecundario(String texto) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("Arial", Font.BOLD, 13));
        boton.setBackground(new Color(70, 130, 180));
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        return boton;
    }
    
    private void iniciarJuego() {
        dispose();
        PantallaSeleccionModalidad pantalla = new PantallaSeleccionModalidad();
        pantalla.setVisible(true);
    }
    
    private void cargarPartida() {
        JOptionPane.showMessageDialog(this,
            "Funcionalidad de carga en desarrollo",
            "Cargar Partida", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void mostrarRanking() {
        JOptionPane.showMessageDialog(this,
            "Funcionalidad de ranking en desarrollo",
            "Ranking", JOptionPane.INFORMATION_MESSAGE);
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                MenuPrincipal menu = new MenuPrincipal();
                menu.setVisible(true);
            }
        });
    }
}