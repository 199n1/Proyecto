package domain;

public enum TipoObstaculoMapa {
    HIELO,
    BALDOSA_CALIENTE,
    FOGATA
}
