package domain;

import java.util.Random;

/**
 * Narval: patrulla aleatoriamente, pero si se alinea con el helado embiste destruyendo bloques
 */
public class Narval extends Enemigo {
    private Helado objetivo;
    private boolean embistiendo;
    private String direccionEmbestida;
    private int contadorFrames;
    private int contadorEmbestida;
    private Random random;

    public Narval(int x, int y, Mapa mapa, Helado objetivo) throws GameException {
        super(x, y, mapa);
        this.objetivo = objetivo;
        this.embistiendo = false;
        this.direccionEmbestida = "";
        this.contadorFrames = 0;
        this.contadorEmbestida = 0;
        this.random = new Random();
    }

    @Override
    public void actualizar() {
        if (!activo) return;
        if (embistiendo) {
            embestir();
        } else {
            contadorFrames++;
            if (contadorFrames >= 30) {
                mover();
                verificarAlineacion();
                contadorFrames = 0;
            }
        }
    }

    @Override
    public void mover() {
        int nx = x, ny = y;
        if (direccion.equals("arriba")) ny--;
        else if (direccion.equals("abajo")) ny++;
        else if (direccion.equals("izquierda")) nx--;
        else if (direccion.equals("derecha")) nx++;

        if (posicionValida(nx, ny)) { 
            x = nx; 
            y = ny; 
        } else {
            cambiarDireccionAleatoria();
        }
    }

    private void verificarAlineacion() {
        if (objetivo == null || !objetivo.isVivo()) return;
        
        if (y == objetivo.getY()) {
            embistiendo = true;
            direccionEmbestida = (objetivo.getX() > x) ? "derecha" : "izquierda";
            contadorEmbestida = 0;
        } else if (x == objetivo.getX()) {
            embistiendo = true;
            direccionEmbestida = (objetivo.getY() > y) ? "abajo" : "arriba";
            contadorEmbestida = 0;
        }
    }

    private void embestir() {
        contadorEmbestida++;
        if (contadorEmbestida % 5 != 0) return;

        int nx = x, ny = y;
        if (direccionEmbestida.equals("arriba")) ny--;
        else if (direccionEmbestida.equals("abajo")) ny++;
        else if (direccionEmbestida.equals("izquierda")) nx--;
        else if (direccionEmbestida.equals("derecha")) nx++;

        if (!mapa.dentroLimites(nx, ny)) { 
            embistiendo = false; 
            return; 
        }

        BloqueHielo bloque = mapa.getBloque(nx, ny);
        if (bloque != null && bloque.isActivo()) {
            if (!bloque.isPermanente()) {
                bloque.destruir();
                mapa.setBloque(nx, ny, null);
            } else {
                embistiendo = false;
                return;
            }
        }

        if (posicionValida(nx, ny)) {
            x = nx;
            y = ny;
        } else {
            embistiendo = false;
        }
    }

    private void cambiarDireccionAleatoria() {
        String[] dirs = {"arriba", "abajo", "izquierda", "derecha"};
        direccion = dirs[random.nextInt(4)];
    }
}