package domain;

/**
 * Clase que representa un bloque de hielo en el juego
 * Los bloques pueden ser creados y destruidos por el helado
 * Existen bloques permanentes (bordes) y bloques temporales
 */
public class BloqueHielo extends Obstaculo {
    
    private boolean permanente;
    
    /**
     * Constructor para bloques normales (no permanentes)
     * @param x Posicion X del bloque
     * @param y Posicion Y del bloque
     */
    public BloqueHielo(int x, int y) {
        super(x, y);
        this.permanente = false;
    }
    
    /**
     * Constructor completo para bloques permanentes o temporales
     * @param x Posicion X del bloque
     * @param y Posicion Y del bloque
     * @param permanente true si el bloque es permanente (no se puede destruir)
     */
    public BloqueHielo(int x, int y, boolean permanente) {
        super(x, y);
        this.permanente = permanente;
    }
    
    @Override
    public void actualizar() {
        // Los bloques de hielo son estaticos, no requieren actualizacion
    }
    
    @Override
    public String getTipo() {
        return "BloqueHielo";
    }
    
    /**
     * Destruye el bloque si no es permanente
     * Los bloques permanentes (bordes del mapa) no pueden ser destruidos
     */
    public void destruir() {
        if (!permanente) {
            activo = false;
        }
    }
    
    /**
     * Reactiva el bloque (lo vuelve a hacer visible)
     */
    public void reactivar() {
        activo = true;
    }
    
    /**
     * Verifica si el bloque es permanente
     * @return true si es permanente, false si puede ser destruido
     */
    public boolean isPermanente() {
        return permanente;
    }
    
    /**
     * Establece si el bloque es permanente
     * @param permanente true para hacer el bloque permanente
     */
    public void setPermanente(boolean permanente) {
        this.permanente = permanente;
    }
}