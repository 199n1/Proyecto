package domain;

/**
 * Clase abstracta que representa un enemigo en el juego
 */
public abstract class Enemigo {
    protected int x;
    protected int y;
    protected String direccion;
    protected boolean activo;
    protected Mapa mapa;

    public Enemigo(int x, int y, Mapa mapa) throws GameException {
        this.x = x;
        this.y = y;
        this.mapa = mapa;
        this.direccion = "abajo";
        this.activo = true;

        if (!mapa.dentroLimites(x, y)) {
            throw GameException.errorInicializacion("Posición inicial fuera de límites");
        }
    }

    public abstract void actualizar();
    public abstract void mover();

    protected boolean posicionValida(int nx, int ny) {
        return mapa.dentroLimites(nx, ny) && mapa.posicionLibre(nx, ny);
    }

    public boolean isActivo() { return activo; }
    public int getX() { return x; }
    public int getY() { return y; }
    public String getDireccion() { return direccion; }
}
