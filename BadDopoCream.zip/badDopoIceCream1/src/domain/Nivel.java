package domain;

import java.util.*;

/**
 * Clase que representa un nivel del juego
 * El usuario define: obstáculo, dos frutas y un enemigo
 * Las frutas aparecen en oleadas, los enemigos desde el inicio
 */
public class Nivel {
    private int numeroNivel;
    private Mapa mapa;
    private ArrayList<Fruta> frutas;              // frutas activas en el escenario
    private ArrayList<Fruta> frutasPendientes;    // frutas que aparecerán en oleadas
    private ArrayList<Enemigo> enemigos;
    private ArrayList<Fogata> fogatas;
    private ArrayList<BaldosaCaliente> baldosasCalientes;
    private Helado helado;
    private int frutasRecolectadas;
    private int totalFrutas;
    private int frameSpawner;
    private static final int FRAMES_ENTRE_OLEADAS = 120; // cada 2s a 60FPS

    /**
     * Constructor de Nivel
     * @param numeroNivel número del nivel
     * @param helado referencia al jugador
     * @param obstaculo tipo de obstáculo elegido por el usuario
     * @param fruta1 primera fruta elegida
     * @param fruta2 segunda fruta elegida
     * @param enemigo enemigo elegido
     */
    public Nivel(int numeroNivel, Helado helado,
                 TipoObstaculoMapa obstaculo,
                 TipoFruta fruta1,
                 TipoFruta fruta2,
                 TipoEnemigo enemigo) throws GameException {
        this.numeroNivel = numeroNivel;
        this.helado = helado;
        this.frutas = new ArrayList<>();
        this.frutasPendientes = new ArrayList<>();
        this.enemigos = new ArrayList<>();
        this.fogatas = new ArrayList<>();
        this.baldosasCalientes = new ArrayList<>();
        this.frameSpawner = 0;

        // Crear mapa según obstáculo elegido
        mapa = new Mapa(15, 15, numeroNivel, obstaculo);

        // Configurar frutas y enemigos según elección del usuario
        configurarFrutas(fruta1, fruta2);
        configurarEnemigo(enemigo);

        // Configurar obstáculos adicionales
        if (obstaculo == TipoObstaculoMapa.BALDOSA_CALIENTE) crearBaldosas();
        if (obstaculo == TipoObstaculoMapa.FOGATA) crearFogatas();

        // Iniciar oleadas de frutas
        inicializarOleadasFrutas();
    }

    // ==================== CONFIGURACIÓN ====================

    private void configurarFrutas(TipoFruta f1, TipoFruta f2) {
        generarFrutas(f1, 8);
        generarFrutas(f2, 8);
        totalFrutas = frutasPendientes.size();
    }

    private void generarFrutas(TipoFruta tipo, int cantidad) {
        for (int i = 0; i < cantidad; i++) {
            int[] pos = encontrarPosicionValida();
            switch (tipo) {
                case UVA: frutasPendientes.add(new Uvas(pos[0], pos[1])); break;
                case BANANO: frutasPendientes.add(new Banano(pos[0], pos[1])); break;
                case CEREZA: frutasPendientes.add(new Cereza(pos[0], pos[1], mapa)); break;
                case PINA: frutasPendientes.add(new Pina(pos[0], pos[1], mapa)); break;
                case CACTUS: frutasPendientes.add(new Cactus(pos[0], pos[1])); break;
            }
        }
    }

    private void configurarEnemigo(TipoEnemigo tipo) throws GameException {
        switch (tipo) {
            case TROLL: enemigos.add(new Troll(2, 2, mapa)); break;
            case MACETA: enemigos.add(new Maceta(7, 2, mapa, helado)); break;
            case CALAMAR: enemigos.add(new Calamar(7, 2, mapa, helado)); break;
            case NARVAL: enemigos.add(new Narval(5, 5, mapa, helado)); break;
        }
    }

    private void crearBaldosas() {
        for (int x = 1; x < 14; x++) {
            baldosasCalientes.add(new BaldosaCaliente(x, 7));
        }
    }

    private void crearFogatas() {
        fogatas.add(new Fogata(4, 4));
        fogatas.add(new Fogata(10, 10));
        fogatas.add(new Fogata(7, 7));
    }

    // ==================== OLEADAS DE FRUTAS ====================

    private void inicializarOleadasFrutas() {
        if (!frutasPendientes.isEmpty()) {
            frutas.add(frutasPendientes.remove(0)); // aparece la primera fruta
        }
    }

    private void actualizarSpawnerFrutas() {
        frameSpawner++;
        if (frameSpawner >= FRAMES_ENTRE_OLEADAS && !frutasPendientes.isEmpty()) {
            frutas.add(frutasPendientes.remove(0));
            frameSpawner = 0;
        }
    }

    // ==================== ACTUALIZACIÓN ====================

    public void actualizar() {
        for (Fruta fruta : frutas) fruta.actualizar();
        for (Enemigo enemigo : enemigos) enemigo.actualizar();
        for (Fogata fogata : fogatas) fogata.actualizar();
        for (BaldosaCaliente b : baldosasCalientes) b.derretirBloque(mapa);

        actualizarSpawnerFrutas();

        // Contar frutas recolectadas
        int activas = 0;
        for (Fruta fruta : frutas) {
            if (fruta.isActiva()) {
                if (fruta instanceof Cactus) {
                    if (((Cactus) fruta).puedeSerRecolectado()) activas++;
                } else activas++;
            }
        }
        frutasRecolectadas = totalFrutas - activas;
    }

    // ==================== COLISIONES ====================

    public Fruta verificarColisionFrutas(Helado helado) {
        for (Fruta fruta : frutas) {
            if (fruta.isActiva() && fruta.getX() == helado.getX() && fruta.getY() == helado.getY()) {
                if (fruta instanceof Cactus) {
                    Cactus c = (Cactus) fruta;
                    if (c.esPeligroso()) { helado.morir(); return null; }
                    else if (c.puedeSerRecolectado()) return fruta;
                } else return fruta;
            }
        }
        return null;
    }

    public boolean verificarColisionEnemigos(Helado helado) {
        for (Enemigo enemigo : enemigos) {
            if (enemigo.isActivo() && enemigo.getX() == helado.getX() && enemigo.getY() == helado.getY()) {
                return true;
            }
        }
        return false;
    }

    public boolean verificarColisionFogatas(Helado helado) {
        for (Fogata fogata : fogatas) {
            if (fogata.eliminaHelado(helado)) return true;
        }
        return false;
    }

    // ==================== UTILIDADES ====================

    private int[] encontrarPosicionValida() {
        Random rand = new Random();
        int x, y;
        do {
            x = rand.nextInt(13) + 1;
            y = rand.nextInt(13) + 1;
        } while (!mapa.posicionLibre(x, y));
        return new int[]{x, y};
    }

    public boolean nivelCompletado() {
        for (Fruta fruta : frutas) {
            if (fruta.isActiva()) {
                if (fruta instanceof Cactus) {
                    if (((Cactus) fruta).puedeSerRecolectado()) return false;
                } else return false;
            }
        }
        return true;
    }

    // ==================== GETTERS ====================

    public Mapa getMapa() { return mapa; }
    public ArrayList<Fruta> getFrutas() { return frutas; }
    public ArrayList<Enemigo> getEnemigos() { return enemigos; }
    public ArrayList<Fogata> getFogatas() { return fogatas; }
    public ArrayList<BaldosaCaliente> getBaldosasCalientes() { return baldosasCalientes; }
    public int getFrutasRecolectadas() { return frutasRecolectadas; }
    public int getTotalFrutas() { return totalFrutas; }
    public int getNumeroNivel() { return numeroNivel; }
}
