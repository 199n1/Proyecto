package domain;

public enum TipoFruta {
    UVA,
    BANANO,
    CEREZA,
    PINA,
    CACTUS
}
