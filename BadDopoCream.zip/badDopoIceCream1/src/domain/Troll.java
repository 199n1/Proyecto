package domain;

import java.util.Random;

/**
 * Troll: patrulla en patrón cuadrado, no rompe bloques ni persigue helados
 */
public class Troll extends Enemigo {
    private int pasosPorLado;
    private int contadorPasos;
    private int contadorFrames;
    private Random random;

    public Troll(int x, int y, Mapa mapa) throws GameException {
        super(x, y, mapa);
        this.pasosPorLado = 5;
        this.contadorPasos = 0;
        this.contadorFrames = 0;
        this.random = new Random();
        this.direccion = "derecha";
    }

    @Override
    public void actualizar() {
        if (!activo) return;
        contadorFrames++;
        if (contadorFrames >= 30) { // cada 0.5s
            mover();
            contadorFrames = 0;
        }
    }

    @Override
    public void mover() {
        int nx = x, ny = y;
        if (direccion.equals("derecha")) nx++;
        else if (direccion.equals("izquierda")) nx--;
        else if (direccion.equals("arriba")) ny--;
        else if (direccion.equals("abajo")) ny++;

        if (posicionValida(nx, ny)) {
            x = nx; y = ny;
            contadorPasos++;
            if (contadorPasos >= pasosPorLado) {
                contadorPasos = 0;
                cambiarDireccion();
            }
        } else {
            cambiarDireccionAleatoria();
        }
    }

    private void cambiarDireccion() {
        if (direccion.equals("derecha")) direccion = "abajo";
        else if (direccion.equals("abajo")) direccion = "izquierda";
        else if (direccion.equals("izquierda")) direccion = "arriba";
        else direccion = "derecha";
    }

    private void cambiarDireccionAleatoria() {
        String[] dirs = {"arriba","abajo","izquierda","derecha"};
        direccion = dirs[random.nextInt(4)];
    }
}
