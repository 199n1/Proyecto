package domain;

public class Helado {
    private int x, y;
    private Mapa mapa;
    private String sabor;
    private boolean vivo;
    private String direccionActual;

    public Helado(int x, int y, Mapa mapa, String sabor) {
        this.x = x;
        this.y = y;
        this.mapa = mapa;
        this.sabor = sabor;
        this.vivo = true;
        this.direccionActual = "derecha";
    }

    public void setMapa(Mapa mapa) {
        this.mapa = mapa;
    }

    public void mover(String direccion) {
        if (!vivo || mapa == null) return;
        this.direccionActual = direccion;
        int nuevoX = x, nuevoY = y;

        if (direccion.equals("arriba")) nuevoY--;
        else if (direccion.equals("abajo")) nuevoY++;
        else if (direccion.equals("izquierda")) nuevoX--;
        else if (direccion.equals("derecha")) nuevoX++;

        // Solo bloquear iglú si el mapa es de hielo
        if (mapa.getTipo() == TipoObstaculoMapa.HIELO) {
            if (nuevoX >= 6 && nuevoX <= 8 && nuevoY >= 6 && nuevoY <= 8) return;
        }

        if (mapa.posicionLibre(nuevoX, nuevoY)) {
            x = nuevoX;
            y = nuevoY;
        }
    }

    public void crearBloques() {
        if (!vivo || mapa == null) return;
        
        int bloqueX = x;
        int bloqueY = y;
        int deltaX = 0, deltaY = 0;

        if (direccionActual.equals("arriba")) deltaY = -1;
        else if (direccionActual.equals("abajo")) deltaY = 1;
        else if (direccionActual.equals("izquierda")) deltaX = -1;
        else if (direccionActual.equals("derecha")) deltaX = 1;

        // Crear bloques en línea hasta encontrar obstáculo
        while (true) {
            bloqueX += deltaX;
            bloqueY += deltaY;
            
            if (!mapa.dentroLimites(bloqueX, bloqueY)) break;
            
            BloqueHielo bloqueExistente = mapa.getBloque(bloqueX, bloqueY);
            if (bloqueExistente != null && bloqueExistente.isActivo()) break;
            
            // Crear nuevo bloque
            BloqueHielo nuevoBloque = new BloqueHielo(bloqueX, bloqueY, false);
            mapa.setBloque(bloqueX, bloqueY, nuevoBloque);
        }
    }

    public void romperBloques() {
        if (!vivo || mapa == null) return;
        
        int bloqueX = x, bloqueY = y;
        int deltaX = 0, deltaY = 0;

        if (direccionActual.equals("arriba")) deltaY = -1;
        else if (direccionActual.equals("abajo")) deltaY = 1;
        else if (direccionActual.equals("izquierda")) deltaX = -1;
        else if (direccionActual.equals("derecha")) deltaX = 1;

        while (true) {
            bloqueX += deltaX;
            bloqueY += deltaY;
            if (!mapa.dentroLimites(bloqueX, bloqueY)) break;

            BloqueHielo bloque = mapa.getBloque(bloqueX, bloqueY);
            if (bloque == null || !bloque.isActivo()) break;
            if (bloque.isPermanente()) break;

            bloque.destruir();
            mapa.setBloque(bloqueX, bloqueY, null);
        }
    }

    public void morir() { vivo = false; }
    public void revivir() { vivo = true; }
    public boolean isVivo() { return vivo; }
    public int getX() { return x; }
    public int getY() { return y; }
    public String getSabor() { return sabor; }
    public String getDireccion() { return direccionActual; }
}