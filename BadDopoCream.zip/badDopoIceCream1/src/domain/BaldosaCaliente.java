package domain;

public class BaldosaCaliente extends Obstaculo {
    public BaldosaCaliente(int x, int y) { super(x, y); }

    @Override
    public void actualizar() { /* no hace nada */ }

    @Override
    public String getTipo() { return "BaldosaCaliente"; }

    public void derretirBloque(Mapa mapa) {
        BloqueHielo b = mapa.getBloque(x, y);
        if (b != null && b.isActivo()) {
            b.destruir();
            mapa.setBloque(x, y, null);
        }
    }
}
