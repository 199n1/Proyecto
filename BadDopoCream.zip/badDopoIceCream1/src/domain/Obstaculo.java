package domain;

/**
 * Clase abstracta que representa un obstaculo en el juego
 * Los obstaculos pueden afectar a helados, enemigos o bloques de hielo
 */
public abstract class Obstaculo {
    
    protected int x;
    protected int y;
    protected boolean activo;
    
    /**
     * Constructor de Obstaculo
     * @param x Posicion X del obstaculo
     * @param y Posicion Y del obstaculo
     */
    public Obstaculo(int x, int y) {
        this.x = x;
        this.y = y;
        this.activo = true;
    }
    
    /**
     * Metodo abstracto para actualizar el comportamiento del obstaculo
     * Cada tipo de obstaculo implementa su propia logica
     */
    public abstract void actualizar();
    
    /**
     * Metodo abstracto para obtener el tipo de obstaculo
     * @return Tipo de obstaculo (ej: "Fogata", "BaldosaCaliente")
     */
    public abstract String getTipo();
    
    /**
     * Verifica si el obstaculo afecta al helado en una posicion
     * @param heladoX Posicion X del helado
     * @param heladoY Posicion Y del helado
     * @return true si el obstaculo afecta al helado
     */
    public boolean afectaHelado(int heladoX, int heladoY) {
        return activo && x == heladoX && y == heladoY;
    }
    
    /**
     * Verifica si el obstaculo esta activo
     * @return true si esta activo
     */
    public boolean isActivo() {
        return activo;
    }
    
    /**
     * Activa el obstaculo
     */
    public void activar() {
        this.activo = true;
    }
    
    /**
     * Desactiva el obstaculo
     */
    public void desactivar() {
        this.activo = false;
    }
    
    // ==================== GETTERS Y SETTERS ====================
    
    public int getX() {
        return x;
    }
    
    public int getY() {
        return y;
    }
    
    public void setX(int x) {
        this.x = x;
    }
    
    public void setY(int y) {
        this.y = y;
    }
    
    public void setActivo(boolean activo) {
        this.activo = activo;
    }
}