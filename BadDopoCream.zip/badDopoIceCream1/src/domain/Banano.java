package domain;

/**
 * Banano: fruta estática que otorga 100 puntos
 */
public class Banano extends Fruta {
    public Banano(int x, int y) { super(x, y, 100); }

    @Override
    public String getTipo() { return "Banano"; }

    @Override
    public void actualizar() { /* no hace nada */ }
}
