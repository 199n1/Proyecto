package domain;

/**
 * Clase que representa una Fogata
 * Los enemigos no sufren daño al tocar el fuego
 * Los helados son eliminados si entran en contacto
 * Pueden apagarse creando y rompiendo un bloque sobre ellas
 * Despues de 10 segundos, el fuego vuelve a encenderse
 */
public class Fogata extends Obstaculo {
    
    private boolean encendida;
    private int contadorFrames;
    private static final int FRAMES_REENCENDIDO = 600; // 10 segundos a 60 FPS
    
    /**
     * Constructor de Fogata
     * @param x Posicion X
     * @param y Posicion Y
     */
    public Fogata(int x, int y) {
        super(x, y);
        this.encendida = true;
        this.contadorFrames = 0;
    }
    
    @Override
    public void actualizar() {
        // Si esta apagada, contar frames para reencender
        if (!encendida) {
            contadorFrames++;
            if (contadorFrames >= FRAMES_REENCENDIDO) {
                encenderse();
            }
        }
    }
    
    @Override
    public String getTipo() {
        return "Fogata";
    }
    
    /**
     * Apaga la fogata (cuando se crea y rompe un bloque sobre ella)
     */
    public void apagar() {
        if (encendida) {
            encendida = false;
            contadorFrames = 0;
        }
    }
    
    /**
     * Enciende la fogata
     */
    public void encenderse() {
        encendida = true;
        contadorFrames = 0;
    }
    
    /**
     * Verifica si la fogata esta encendida
     * @return true si esta encendida (peligrosa para helados)
     */
    public boolean estaEncendida() {
        return encendida && activo;
    }
    
    /**
     * Verifica si un helado esta en contacto con la fogata encendida
     * @param helado Helado a verificar
     * @return true si el helado toca la fogata encendida
     */
    public boolean eliminaHelado(Helado helado) {
        return encendida && activo && afectaHelado(helado.getX(), helado.getY());
    }
    
    public void setEncendida(boolean encendida) {
        this.encendida = encendida;
    }
}