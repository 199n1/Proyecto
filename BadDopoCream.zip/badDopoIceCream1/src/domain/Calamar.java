package domain;

/**
 * Calamar: persigue al helado y destruye bloques de hielo en su camino (uno a la vez)
 */
public class Calamar extends Enemigo {
    private Helado objetivo;
    private int contadorFrames;

    public Calamar(int x, int y, Mapa mapa, Helado objetivo) throws GameException {
        super(x, y, mapa);
        this.objetivo = objetivo;
        this.contadorFrames = 0;
    }

    @Override
    public void actualizar() {
        if (!activo) return;
        contadorFrames++;
        if (contadorFrames >= 25) { // cada ~0.4s
            mover();
            contadorFrames = 0;
        }
    }

    @Override
    public void mover() {
        if (objetivo == null || !objetivo.isVivo()) return;
        int dx = objetivo.getX() - x;
        int dy = objetivo.getY() - y;
        int nx = x, ny = y;

        if (Math.abs(dx) > Math.abs(dy)) {
            if (dx > 0) { nx++; direccion = "derecha"; }
            else if (dx < 0) { nx--; direccion = "izquierda"; }
        } else {
            if (dy > 0) { ny++; direccion = "abajo"; }
            else if (dy < 0) { ny--; direccion = "arriba"; }
        }

        BloqueHielo bloque = mapa.getBloque(nx, ny);
        if (bloque != null && bloque.isActivo() && !bloque.isPermanente()) {
            bloque.destruir(); // rompe un bloque
            mapa.setBloque(nx, ny, null);
            return;
        }

        if (posicionValida(nx, ny)) { x = nx; y = ny; }
    }
}
