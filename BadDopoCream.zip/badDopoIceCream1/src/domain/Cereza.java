package domain;

import java.util.Random;

/**
 * Cereza: se teletransporta cada 20 segundos a una posición libre.
 * Otorga 150 puntos.
 */
public class Cereza extends Fruta {
    private final Mapa mapa;
    private int contadorFrames;
    private static final int FRAMES_TELEPORT = 1200; // 20s a 60FPS
    private static final int INTENTOS_MAX = 200;     // evita bucle infinito

    public Cereza(int x, int y, Mapa mapa) {
        super(x, y, 150);
        if (mapa == null) {
            throw new IllegalArgumentException("Mapa no puede ser null para Cereza");
        }
        this.mapa = mapa;
        this.contadorFrames = 0;
    }

    @Override
    public String getTipo() { return "Cereza"; }

    @Override
    public void actualizar() {
        if (!activa) return;
        contadorFrames++;
        if (contadorFrames >= FRAMES_TELEPORT) {
            teletransportar();
            contadorFrames = 0;
        }
    }

    /**
     * Teletransporta a una celda libre del mapa.
     * Evita la zona del iglú si el obstáculo del mapa es HIELO.
     */
    private void teletransportar() {
        Random rand = new Random();
        int intentos = 0;

        while (intentos < INTENTOS_MAX) {
            int nx = rand.nextInt(mapa.getAncho());
            int ny = rand.nextInt(mapa.getAlto());

            if (esZonaIglu(nx, ny)) {
                intentos++;
                continue;
            }

            if (mapa.posicionLibre(nx, ny)) {
                this.x = nx;
                this.y = ny;
                return;
            }
            intentos++;
        }

        // Respaldo: busca la primera posición libre en barrido
        for (int ny = 0; ny < mapa.getAlto(); ny++) {
            for (int nx = 0; nx < mapa.getAncho(); nx++) {
                if (!esZonaIglu(nx, ny) && mapa.posicionLibre(nx, ny)) {
                    this.x = nx;
                    this.y = ny;
                    return;
                }
            }
        }
        // Si no hay ninguna libre, no se mueve.
    }

    private boolean esZonaIglu(int x, int y) {
        return mapa.getTipo() == TipoObstaculoMapa.HIELO
                && x >= 6 && x <= 8 && y >= 6 && y <= 8;
    }
}
