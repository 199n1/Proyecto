package domain;

/**
 * Maceta: persigue al helado, pero no rompe bloques
 */
public class Maceta extends Enemigo {
    private Helado objetivo;
    private int contadorFrames;

    public Maceta(int x, int y, Mapa mapa, Helado objetivo) throws GameException {
        super(x, y, mapa);
        this.objetivo = objetivo;
        this.contadorFrames = 0;
    }

    @Override
    public void actualizar() {
        if (!activo) return;
        contadorFrames++;
        if (contadorFrames >= 20) { // cada 0.33s
            mover();
            contadorFrames = 0;
        }
    }

    @Override
    public void mover() {
        if (objetivo == null || !objetivo.isVivo()) return;
        int dx = objetivo.getX() - x;
        int dy = objetivo.getY() - y;
        int nx = x, ny = y;

        if (Math.abs(dx) > Math.abs(dy)) {
            if (dx > 0) { nx++; direccion = "derecha"; }
            else if (dx < 0) { nx--; direccion = "izquierda"; }
        } else {
            if (dy > 0) { ny++; direccion = "abajo"; }
            else if (dy < 0) { ny--; direccion = "arriba"; }
        }

        if (posicionValida(nx, ny)) { x = nx; y = ny; }
    }
}
