package persistence;

import java.io.*;

/**
 * Clase para gestionar el guardado y carga de partidas
 * Guarda el estado completo del juego en archivos .dat
 */
public class GestorPartidas {
    
    private static final String CARPETA_GUARDADOS = "guardados/";
    private static final String EXTENSION = ".dat";
    
    /**
     * Clase interna para representar una partida guardada
     */
    public static class PartidaGuardada implements Serializable {
        private static final long serialVersionUID = 1L;
        
        public String modalidad;
        public String colorHelado;
        public int nivelActual;
        public int vidasRestantes;
        public int puntaje;
        public int frutasRecolectadas;
        public int heladoX;
        public int heladoY;
        
        public PartidaGuardada(String modalidad, String colorHelado, int nivelActual, 
                             int vidasRestantes, int puntaje, int frutasRecolectadas,
                             int heladoX, int heladoY) {
            this.modalidad = modalidad;
            this.colorHelado = colorHelado;
            this.nivelActual = nivelActual;
            this.vidasRestantes = vidasRestantes;
            this.puntaje = puntaje;
            this.frutasRecolectadas = frutasRecolectadas;
            this.heladoX = heladoX;
            this.heladoY = heladoY;
        }
    }
    
    /**
     * Guarda una partida en archivo
     */
    public boolean guardarPartida(String nombreArchivo, PartidaGuardada partida) {
        try {
            File carpeta = new File(CARPETA_GUARDADOS);
            if (!carpeta.exists()) {
                carpeta.mkdirs();
            }
            
            String rutaCompleta = CARPETA_GUARDADOS + nombreArchivo + EXTENSION;
            FileOutputStream fos = new FileOutputStream(rutaCompleta);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            
            oos.writeObject(partida);
            
            oos.close();
            fos.close();
            
            return true;
            
        } catch (IOException e) {
            System.err.println("Error al guardar partida: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Carga una partida desde archivo
     */
    public PartidaGuardada cargarPartida(String nombreArchivo) {
        try {
            String rutaCompleta = CARPETA_GUARDADOS + nombreArchivo + EXTENSION;
            File archivo = new File(rutaCompleta);
            
            if (!archivo.exists()) {
                return null;
            }
            
            FileInputStream fis = new FileInputStream(rutaCompleta);
            ObjectInputStream ois = new ObjectInputStream(fis);
            
            PartidaGuardada partida = (PartidaGuardada) ois.readObject();
            
            ois.close();
            fis.close();
            
            return partida;
            
        } catch (IOException e) {
            System.err.println("Error al cargar partida: " + e.getMessage());
            return null;
        } catch (ClassNotFoundException e) {
            System.err.println("Error al cargar partida: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Verifica si existe una partida guardada
     */
    public boolean existePartida(String nombreArchivo) {
        String rutaCompleta = CARPETA_GUARDADOS + nombreArchivo + EXTENSION;
        File archivo = new File(rutaCompleta);
        return archivo.exists();
    }
    
    /**
     * Elimina una partida guardada
     */
    public boolean eliminarPartida(String nombreArchivo) {
        try {
            String rutaCompleta = CARPETA_GUARDADOS + nombreArchivo + EXTENSION;
            File archivo = new File(rutaCompleta);
            return archivo.delete();
        } catch (Exception e) {
            System.err.println("Error al eliminar partida: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Lista todas las partidas guardadas
     */
    public String[] listarPartidas() {
        File carpeta = new File(CARPETA_GUARDADOS);
        if (!carpeta.exists()) {
            return new String[0];
        }
        
        File[] archivos = carpeta.listFiles(new FilenameFilter() {
            public boolean accept(File dir, String name) {
                return name.endsWith(EXTENSION);
            }
        });
        
        if (archivos == null || archivos.length == 0) {
            return new String[0];
        }
        
        String[] nombres = new String[archivos.length];
        for (int i = 0; i < archivos.length; i++) {
            String nombre = archivos[i].getName();
            nombres[i] = nombre.substring(0, nombre.length() - EXTENSION.length());
        }
        
        return nombres;
    }
}