package persistence;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;

/**
 * Clase para gestionar el ranking de puntuaciones
 */
public class GestorPuntuaciones {
    
    private static final String ARCHIVO_PUNTUACIONES = "puntuaciones.dat";
    private static final int MAX_PUNTUACIONES = 10;
    
    /**
     * Clase interna para representar una puntuacion
     */
    public static class Puntuacion implements Serializable, Comparable<Puntuacion> {
        private static final long serialVersionUID = 1L;
        
        public String nombreJugador;
        public int puntos;
        public int nivelAlcanzado;
        public String modalidad;
        public String fecha;
        
        public Puntuacion(String nombreJugador, int puntos, int nivelAlcanzado, String modalidad) {
            this.nombreJugador = nombreJugador;
            this.puntos = puntos;
            this.nivelAlcanzado = nivelAlcanzado;
            this.modalidad = modalidad;
            this.fecha = obtenerFechaActual();
        }
        
        private String obtenerFechaActual() {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm");
            return sdf.format(new java.util.Date());
        }
        
        public int compareTo(Puntuacion otra) {
            return Integer.compare(otra.puntos, this.puntos);
        }
        
        public String toString() {
            return nombreJugador + " - " + puntos + " pts (Nivel " + nivelAlcanzado + ")";
        }
    }
    
    /**
     * Guarda una nueva puntuacion si esta entre las mejores
     */
    public boolean guardarPuntuacion(Puntuacion puntuacion) {
        try {
            ArrayList<Puntuacion> puntuaciones = cargarPuntuaciones();
            
            puntuaciones.add(puntuacion);
            Collections.sort(puntuaciones);
            
            if (puntuaciones.size() > MAX_PUNTUACIONES) {
                puntuaciones = new ArrayList<Puntuacion>(puntuaciones.subList(0, MAX_PUNTUACIONES));
            }
            
            FileOutputStream fos = new FileOutputStream(ARCHIVO_PUNTUACIONES);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            
            oos.writeObject(puntuaciones);
            
            oos.close();
            fos.close();
            
            return puntuaciones.contains(puntuacion);
            
        } catch (IOException e) {
            System.err.println("Error al guardar puntuacion: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Carga las mejores puntuaciones
     */
    public ArrayList<Puntuacion> cargarPuntuaciones() {
        try {
            File archivo = new File(ARCHIVO_PUNTUACIONES);
            
            if (!archivo.exists()) {
                return new ArrayList<Puntuacion>();
            }
            
            FileInputStream fis = new FileInputStream(ARCHIVO_PUNTUACIONES);
            ObjectInputStream ois = new ObjectInputStream(fis);
            
            ArrayList<Puntuacion> puntuaciones = (ArrayList<Puntuacion>) ois.readObject();
            
            ois.close();
            fis.close();
            
            return puntuaciones;
            
        } catch (IOException e) {
            System.err.println("Error al cargar puntuaciones: " + e.getMessage());
            return new ArrayList<Puntuacion>();
        } catch (ClassNotFoundException e) {
            System.err.println("Error al cargar puntuaciones: " + e.getMessage());
            return new ArrayList<Puntuacion>();
        }
    }
    
    /**
     * Obtiene las mejores N puntuaciones
     */
    public ArrayList<Puntuacion> obtenerTop(int cantidad) {
        ArrayList<Puntuacion> todas = cargarPuntuaciones();
        
        if (todas.size() <= cantidad) {
            return todas;
        }
        
        return new ArrayList<Puntuacion>(todas.subList(0, cantidad));
    }
    
    /**
     * Verifica si una puntuacion entraria en el top 10
     */
    public boolean esTopPuntuacion(int puntos) {
        ArrayList<Puntuacion> puntuaciones = cargarPuntuaciones();
        
        if (puntuaciones.size() < MAX_PUNTUACIONES) {
            return true;
        }
        
        Puntuacion peor = puntuaciones.get(puntuaciones.size() - 1);
        return puntos > peor.puntos;
    }
    
    /**
     * Limpia todas las puntuaciones guardadas
     */
    public boolean limpiarPuntuaciones() {
        try {
            File archivo = new File(ARCHIVO_PUNTUACIONES);
            return archivo.delete();
        } catch (Exception e) {
            System.err.println("Error al limpiar puntuaciones: " + e.getMessage());
            return false;
        }
    }
}